from setuptools import setup

setup(name = 'data_scilib',
        version = '0.0.1',
        description = 'Data science library for python.',
        url = '#',
        author = 'test',
        author_email = 'test@test.com',
        license = 'MIT',
        packages = ['data_scilib'],
        zip_safe = False)